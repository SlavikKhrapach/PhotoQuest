<?php

//Connect to the database
define("DB_DSN", "mysql:dbname=photoquest");
define("DB_USERNAME", "root");
define("DB_PASSWORD", "");